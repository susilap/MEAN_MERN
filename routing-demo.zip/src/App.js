import { BrowserRouter as Router,Routes,Route,Link,Outlet} from 'react-router-dom'
import HttpDemo from './HttpDemo';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Container from './Container';
import AuthorPage from './AuthorPage';

const User = () =>{
  return(
    <>
    <h1>user Component</h1>
  <Outlet/>
    <nav>
      <Link to="/user/contact">Contact  | </Link>
      <Link to="/user/about"> About</Link>
    </nav>
    </>
  )
}

function App() {
  return (
    <Router>
    <div className="App">
      <Container/>
      <br/><HttpDemo/>
      <br/><AuthorPage/>
      <ul className='App-header'>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/user/contact">Contact Us</Link>
        </li>
        <li>
          <Link to="/user/about">About Us</Link>
        </li>
        <li><Link to="/user">User</Link></li>
      </ul>
      <Routes>
      <Route index  element={<Home />}/>
      <Route exact path='/home' element={<Home />}/>

      <Route exact path='user' element={<User />}>
      <Route exact path='/user/contact' element={<Contact />} />
      <Route exact path='/user/about' element={<About />} />

      </Route>
      {/* <Route path='*' element={<NoMatch />} /> */}

      </Routes>
          </div>
          </Router>
  );
}

export default App;
