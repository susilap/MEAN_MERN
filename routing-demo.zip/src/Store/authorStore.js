import {EventEmitter} from "events";
import Dispatcher from "../Dispatcher/appDispatcher";
class authorStore extends EventEmitter
{
    constructor()
    {
        super();
        this.authors={
            authorName:"Sachin"
        },
        {
            authorName:"Rahul"
        },
        {
            authorName:"Dravid"
        }
    }
    createAuthor(action)
    {
        switch(action.type)
        {
            case "CREATE_AUTHOR":{
                this.createAuthor(action.authorName);
                break;
            }
        }
    }
    createAuthor(authorName)
    {
        this.authors.push({authorName});
        this.emit("change");
    }
    getAllAuthors()
    {
        return this.authors;
    }
    handleActions(action)
    {
        switch(action.type)
        {
            case "CREATE_AUTHOR":{
                this.createAuthor(action.authorName);
                break;
            }
        }

    }
}
const authorStore = new authorStore();
Dispatcher.register(authorStore.handleActions.bind(authorStore));
export default authorStore;