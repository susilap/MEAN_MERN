import React from "react";
import axios from 'axios';
class HttpDemo extends React.Component
{
    constructor()
    {
        super();
        axios.get("https://jsonplaceholder.typicode.com/posts",{

            userId:1
        }).then((response)=>{
            console.log("Response:"+JSON.stringify(response.data));
        }).catch((error)=>{console.log("no response for this request")})
    }
    render()
    {
        return(
            <>
            <h1>Axios Http client (Get)</h1>
            </>
        )
    }
}

export default HttpDemo;