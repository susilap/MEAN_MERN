import React, { Component } from "react";

let BaseComponent = (ModifiedComponent)=>class extends Component{
    constructor()
    {
        super();
        this.state={
            count:0
        }
    }
    incrementCount()
    {
        this.setState({
            count:this.state.count+1
        })
    }
    render()
    {
        return(
            <>
            <h1> i m from base component</h1>
            <ModifiedComponent count={this.state.count} increment={()=>this.incrementCount()}/>
            </>
        )
    }
}

const Button=(props)=>{
    console.log(props);
    return(
        <button onClick={props.increment}>Count:{props.count}</button>
    )
}

let NewButton= BaseComponent(Button);

const Label=()=>{return(<>i m from label</>)}

const NewLabel = BaseComponent(Label);

class Container extends React.Component
{
    render(){
        return(
            <>
            <NewButton/>
            <NewLabel/>
            </>
        )
    }
}

export default Container;