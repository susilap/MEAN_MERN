import Dispatcher from "../Dispatcher/appDispatcher";
export function createAuthor(authorName)
{
    Dispatcher.dispatch({
        type:"CREATE_AUTHOR",
        authorName
    });
}